#!/bin/sh
[ "$1" = bound ] && echo "$serverid"
